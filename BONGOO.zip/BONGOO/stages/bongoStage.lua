
function onCreate()
	makeLuaSprite('white', '', -200,-100);
	makeGraphic('white',3000, 1400, '0xffFFFFFF');
	setLuaSpriteScrollFactor('white', 0, 0);
	addLuaSprite('white', false);

	if difficulty == 2 then
		precacheImage("explode");
		precacheSound('aaa');

		makeAnimatedLuaSprite("explode", "explode", defaultBoyfriendX, defaultBoyfriendY+100);
		addAnimationByPrefix("explode", "boom", "boom", 24, false);
		setScrollFactor("explode", 1, 1);
	end
end

function onBeatHit()
	if curBeat == 210 and difficulty == 2 then
		addLuaSprite("explode", true);
		objectPlayAnimation("explode", "boom", true);
		playSound('aaa', 1);
		setProperty('boyfriend.visible', false);
	end
end